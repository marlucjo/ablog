---
layout: default
---

# Introduction

GitHub is a code hosting platform for version control and collaboration. It lets you and others work together on projects from anywhere.

# Content

1. [Iruelas](https://iruelas.readthedocs.io/es/main/index.html).
2. [RF](/markdown_files/RF.md)
3. ...
4. [Post](/docs/publicaciones.md)

# References

1. [Quickstart](https://docs.github.com/es/pages/quickstart)

# Style

1. [Style guide](/markdown_files/style.md)
